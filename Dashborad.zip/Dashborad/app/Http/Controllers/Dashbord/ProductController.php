<?php

namespace App\Http\Controllers\Dashboard;


use Illuminate\Http\Request;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\App;
use App\Http\Controllers\Controller;

class ProductController extends Controller
{


    public function index(Request $request)
    {
        $products = DB::table('products')->select('id','name_'.App::currentLocale().' AS name','desc_'.App::currentLocale().' AS desc','price','quantity')->get(); // SELECT * FROM `products`
        if($request->wantsJson()){
            return $this->data(compact('products'),__('message.all.products'));
        }
        return view('products.index', compact('products'));
    }
}

